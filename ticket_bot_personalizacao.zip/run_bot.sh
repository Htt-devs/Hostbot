#!/bin/bash

# Script de monitoramento do bot - reinicia automaticamente se cair
# Mantém o bot online 24/7

BOT_DIR="/home/ubuntu/ticket_bot_v3"
LOG_FILE="$BOT_DIR/bot_monitor.log"
PID_FILE="$BOT_DIR/bot.pid"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Iniciando monitoramento do bot..." >> "$LOG_FILE"

while true; do
    # Verifica se o processo anterior ainda está rodando
    if [ -f "$PID_FILE" ]; then
        OLD_PID=$(cat "$PID_FILE")
        if ps -p "$OLD_PID" > /dev/null 2>&1; then
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] Bot ainda rodando (PID: $OLD_PID)" >> "$LOG_FILE"
            sleep 30
            continue
        fi
    fi

    # Bot caiu ou não está rodando, reinicia
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Iniciando bot..." >> "$LOG_FILE"
    cd "$BOT_DIR"
    python3 main.py >> "$LOG_FILE" 2>&1 &
    NEW_PID=$!
    echo "$NEW_PID" > "$PID_FILE"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Bot iniciado com PID: $NEW_PID" >> "$LOG_FILE"
    
    # Aguarda 30 segundos antes de verificar novamente
    sleep 30
done
