import discord
from discord import app_commands
from discord.ext import commands
import asyncio, json, time, traceback, uuid, requests
from utils.config_manager import load_config, save_config, is_admin, is_owner
from utils.ia import IAClient
from keep_alive_cors import start_keep_alive_server

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents)

# Estado em memória
historicos = {}            # canal_id -> mensagens
claims = {}                # canal_id -> user_id
travas_abertura = set()    # user_ids abrindo ticket agora
_ready_once = False        # garante on_ready idempotente

def emj(cfg, nome):
    return cfg.get("emojis", {}).get(nome, "")

def get_ia(cfg):
    return IAClient(
        api_key=cfg.get("groq_api_key", ""),
        model=cfg.get("groq_model", "llama-3.3-70b-versatile"),
        system_prompt=cfg.get("prompt_ia", "Você é um assistente útil."),
    )

def notify_keep_alive(event_type, data=None):
    """Notifica o servidor keep_alive sobre eventos do bot"""
    try:
        payload = {"event": event_type}
        if data:
            payload.update(data)
        requests.post("http://localhost:8000/api/bot-event", json=payload, timeout=2)
    except Exception as e:
        print(f"Erro ao notificar keep_alive: {e}")

# ----------------- TICKET CRIAÇÃO -----------------
async def criar_ticket(interaction: discord.Interaction, motivo: str = "Suporte"):
    cfg = load_config()
    autor = interaction.user
    guild = interaction.guild

    if autor.id in travas_abertura:
        try:
            if not interaction.response.is_done():
                await interaction.response.send_message(f"{emj(cfg,'erro')} Aguarde, já estamos abrindo seu ticket...", ephemeral=True)
        except Exception: pass
        return

    travas_abertura.add(autor.id)
    try:
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=True)

        nome_base = f"ticket-{autor.name}".lower().replace(" ", "-")[:80]
        existente = discord.utils.get(guild.text_channels, name=nome_base)
        if existente:
            await interaction.followup.send(f"{emj(cfg,'erro')} Você já possui um ticket aberto: {existente.mention}", ephemeral=True)
            return

        categoria = None
        cat_id = cfg.get("categoria_tickets_id")
        if cat_id:
            try: categoria = guild.get_channel(int(cat_id))
            except Exception: pass

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            autor: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True, embed_links=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True, embed_links=True),
        }
        if cfg.get("admin_role_id"):
            try:
                role = guild.get_role(int(cfg["admin_role_id"]))
                if role: overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True)
            except Exception: pass

        canal = await guild.create_text_channel(nome_base, category=categoria, overwrites=overwrites, topic=f"Ticket de {autor} | {motivo}")

        embed = discord.Embed(
            title=f"{emj(cfg,'ticket')} Ticket Aberto",
            description=cfg.get("ticket_descricao", "Bem-vindo!") + f"\n\n**Categoria:** {motivo}",
            color=0x5865F2,
        )
        embed.set_footer(text=f"Aberto por {autor}", icon_url=autor.display_avatar.url)

        await canal.send(content=f"{autor.mention}", embed=embed, view=TicketView())

        view_ir = discord.ui.View()
        view_ir.add_item(discord.ui.Button(label="Ir para o Ticket", url=canal.jump_url, emoji="🎫"))
        await interaction.followup.send(f"{emj(cfg,'ok')} Seu ticket foi criado!", view=view_ir, ephemeral=True)
        
        # Notifica o keep_alive sobre o novo ticket
        notify_keep_alive("ticket_created")

        historicos[canal.id] = [{"role": "user", "content": f"Olá! Acabei de abrir um ticket sobre: {motivo}. Me cumprimente e pergunte como pode ajudar."}]
        ia = get_ia(cfg)
        try:
            texto, sem_credito = await ia.responder(historicos[canal.id])
            if sem_credito: await avisar_sem_credito(canal, cfg)
            elif texto:
                historicos[canal.id].append({"role": "assistant", "content": texto})
                await canal.send(texto)
        except Exception as e: print(f"Erro IA: {e}")
    except Exception as e:
        print(f"Erro ao criar ticket: {e}")
        traceback.print_exc()
    finally: travas_abertura.discard(autor.id)

async def avisar_sem_credito(canal, cfg):
    if cfg.get("creditos_acabaram_avisado"): return
    cfg["creditos_acabaram_avisado"] = True
    save_config(cfg)
    embed = discord.Embed(title=f"{emj(cfg,'erro')} Créditos da IA esgotados", description="A API da IA está sem créditos. Aguarde atendimento humano.", color=0xED4245)
    await canal.send(embed=embed)

# ----------------- VIEWS -----------------
class TicketView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)
    @discord.ui.button(label="Reivindicar", style=discord.ButtonStyle.success, custom_id="ticket_claim_v2")
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message(f"{emj(cfg,'erro')} Apenas admins podem reivindicar.", ephemeral=True); return
        if interaction.channel.id in claims:
            user = interaction.guild.get_member(claims[interaction.channel.id])
            await interaction.response.send_message(f"{emj(cfg,'erro')} Já reivindicado por {user.mention if user else 'alguém'}.", ephemeral=True); return
        claims[interaction.channel.id] = interaction.user.id
        embed = discord.Embed(title=f"{emj(cfg,'claim')} Ticket Reivindicado", description=f"{interaction.user.mention} chegou e está cuidando do seu atendimento agora! ✨", color=0xFEE75C)
        await interaction.response.send_message(embed=embed)

    @discord.ui.button(label="Fechar Ticket", style=discord.ButtonStyle.danger, custom_id="ticket_close_v2")
    async def fechar(self, interaction: discord.Interaction, button: discord.ui.Button):
        cfg = load_config()
        if not is_admin(interaction.user, cfg):
            await interaction.response.send_message(f"{emj(cfg,'erro')} Apenas admins podem fechar.", ephemeral=True); return
        await interaction.response.send_message(f"{emj(cfg,'fechar')} Fechando ticket em 5 segundos...")
        await asyncio.sleep(5)
        historicos.pop(interaction.channel.id, None)
        claims.pop(interaction.channel.id, None)
        try: await interaction.channel.delete(reason=f"Fechado por {interaction.user}")
        except Exception: pass

class AbrirBotaoView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)
    @discord.ui.button(label="Abrir Ticket", style=discord.ButtonStyle.primary, custom_id="abrir_ticket_botao_v2", emoji="🎫")
    async def abrir(self, interaction: discord.Interaction, button: discord.ui.Button):
        await criar_ticket(interaction, motivo="Suporte")

class AbrirSelectView(discord.ui.View):
    def __init__(self, options):
        super().__init__(timeout=None)
        opts = options or [{"label": "Suporte", "descricao": "Ajuda geral", "emoji": "🛠️", "value": "suporte_padrao"}]
        
        seen_values = set()
        unique_opts = []
        for o in opts:
            val = o.get("value", o["label"])
            if val not in seen_values:
                seen_values.add(val)
                unique_opts.append(o)
        
        select = discord.ui.Select(
            placeholder="Escolha uma categoria...",
            custom_id="abrir_ticket_select_v2",
            options=[discord.SelectOption(label=o["label"], description=o.get("descricao",""), emoji=o.get("emoji"), value=o.get("value", o["label"])) for o in unique_opts],
        )
        async def cb(interaction: discord.Interaction):
            selecionado = next((o["label"] for o in unique_opts if o.get("value", o["label"]) == select.values[0]), select.values[0])
            await criar_ticket(interaction, motivo=selecionado)
        select.callback = cb
        self.add_item(select)

# ----------------- IA RESPONDE -----------------
@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild: return
    if message.channel.name and message.channel.name.startswith("ticket-"):
        cfg = load_config()
        if message.channel.id in claims: return
        hist = historicos.setdefault(message.channel.id, [])
        hist.append({"role": "user", "content": message.content[:2000]})
        async with message.channel.typing():
            ia = get_ia(cfg)
            try:
                texto, sem_credito = await ia.responder(hist[-20:])
                if sem_credito: await avisar_sem_credito(message.channel, cfg); return
                if texto:
                    hist.append({"role": "assistant", "content": texto})
                    await message.channel.send(texto)
                    # Notifica o keep_alive sobre mensagem processada
                    notify_keep_alive("message_processed")
            except Exception as e: print(f"Erro IA responder: {e}")
    await bot.process_commands(message)

# ----------------- COMANDOS -----------------
@bot.tree.command(name="set", description="Envia o painel de abertura de tickets")
async def set_painel(interaction: discord.Interaction):
    cfg = load_config()
    if not is_admin(interaction.user, cfg):
        await interaction.response.send_message(f"{emj(cfg,'erro')} Sem permissão.", ephemeral=True); return
    await interaction.response.defer(ephemeral=True)
    embed = discord.Embed(title=f"{emj(cfg,'ticket')} Central de Atendimento", description=f"{emj(cfg,'estrela')} Precisa de ajuda? Abra um ticket abaixo!\n{emj(cfg,'ia')} Atendimento por IA inteligente.", color=0x5865F2)
    view = AbrirSelectView(cfg.get("menu_options", [])) if cfg.get("modo_abertura") == "select" else AbrirBotaoView()
    try:
        await interaction.channel.send(embed=embed, view=view)
        await interaction.followup.send(f"{emj(cfg,'ok')} Painel enviado!", ephemeral=True)
    except Exception as e: await interaction.followup.send(f"{emj(cfg,'erro')} Erro: {e}", ephemeral=True)

# ----------------- MODAIS E VIEWS DE CONFIG -----------------
class ModalPromptIA(discord.ui.Modal, title="Configurar Prompt da IA"):
    prompt = discord.ui.TextInput(label="Prompt do sistema", style=discord.TextStyle.paragraph, max_length=2000, required=True)
    def __init__(self, current_val): super().__init__(); self.prompt.default = current_val
    async def on_submit(self, interaction):
        cfg = load_config(); cfg["prompt_ia"] = str(self.prompt.value); save_config(cfg)
        await interaction.response.send_message("✅ Prompt atualizado!", ephemeral=True)

class ModalDescricao(discord.ui.Modal, title="Descrição do Ticket"):
    desc = discord.ui.TextInput(label="Descrição", style=discord.TextStyle.paragraph, max_length=1000, required=True)
    def __init__(self, current_val): super().__init__(); self.desc.default = current_val
    async def on_submit(self, interaction):
        cfg = load_config(); cfg["ticket_descricao"] = str(self.desc.value); save_config(cfg)
        await interaction.response.send_message("✅ Descrição atualizada!", ephemeral=True)

class ModalAddOpcao(discord.ui.Modal, title="Adicionar opção ao menu"):
    label = discord.ui.TextInput(label="Nome (label)", required=True, max_length=80)
    descricao = discord.ui.TextInput(label="Descrição", required=False, max_length=100)
    emoji = discord.ui.TextInput(label="Emoji (ex: 🛠️ ou <:nome:id>)", required=False, max_length=80)
    async def on_submit(self, interaction):
        cfg = load_config(); opts = cfg.get("menu_options", [])
        if len(opts) >= 25: await interaction.response.send_message("❌ Máximo de 25 opções.", ephemeral=True); return
        valor_unico = str(uuid.uuid4())[:12]
        opts.append({
            "label": str(self.label.value),
            "descricao": str(self.descricao.value) if self.descricao.value else "",
            "emoji": str(self.emoji.value) if self.emoji.value else None,
            "value": valor_unico
        })
        cfg["menu_options"] = opts; save_config(cfg)
        await interaction.response.send_message(f"✅ Opção **{self.label.value}** adicionada!", ephemeral=True)

class ModalAPIKey(discord.ui.Modal, title="Configurar API Key da IA"):
    api_key = discord.ui.TextInput(label="API Key (Groq)", style=discord.TextStyle.paragraph, max_length=500, required=True)
    def __init__(self, current_val): super().__init__(); self.api_key.default = current_val
    async def on_submit(self, interaction):
        cfg = load_config(); cfg["groq_api_key"] = str(self.api_key.value); save_config(cfg)
        await interaction.response.send_message("✅ API Key atualizada!", ephemeral=True)

class ModalModelo(discord.ui.Modal, title="Configurar Modelo da IA"):
    modelo = discord.ui.TextInput(label="Nome do modelo", style=discord.TextStyle.short, max_length=100, required=True)
    def __init__(self, current_val): super().__init__(); self.modelo.default = current_val
    async def on_submit(self, interaction):
        cfg = load_config(); cfg["groq_model"] = str(self.modelo.value); save_config(cfg)
        await interaction.response.send_message(f"✅ Modelo alterado para: **{self.modelo.value}**", ephemeral=True)

class SelectCategoria(discord.ui.ChannelSelect):
    def __init__(self): super().__init__(placeholder="Selecione a categoria de tickets...", channel_types=[discord.ChannelType.category])
    async def callback(self, interaction: discord.Interaction):
        cfg = load_config(); cfg["categoria_tickets_id"] = str(self.values[0].id); save_config(cfg)
        await interaction.response.send_message(f"✅ Categoria definida para: **{self.values[0].name}**", ephemeral=True)

class SelectCargoAdmin(discord.ui.RoleSelect):
    def __init__(self): super().__init__(placeholder="Selecione o cargo de admin...")
    async def callback(self, interaction: discord.Interaction):
        cfg = load_config(); cfg["admin_role_id"] = str(self.values[0].id); save_config(cfg)
        await interaction.response.send_message(f"✅ Cargo admin definido para: **{self.values[0].name}**", ephemeral=True)

class MenuPrincipal(discord.ui.View):
    def __init__(self): super().__init__(timeout=300)
    @discord.ui.button(label="Prompt IA", style=discord.ButtonStyle.primary, emoji="🧠")
    async def b1(self, interaction, button): cfg = load_config(); await interaction.response.send_modal(ModalPromptIA(cfg.get("prompt_ia", "")))
    @discord.ui.button(label="API Key", style=discord.ButtonStyle.primary, emoji="🔑")
    async def b2(self, interaction, button): cfg = load_config(); await interaction.response.send_modal(ModalAPIKey(cfg.get("groq_api_key", "")))
    @discord.ui.button(label="Modelo IA", style=discord.ButtonStyle.primary, emoji="⚙️")
    async def b3(self, interaction, button): cfg = load_config(); await interaction.response.send_modal(ModalModelo(cfg.get("groq_model", "llama-3.3-70b-versatile")))
    @discord.ui.button(label="Descrição Ticket", style=discord.ButtonStyle.secondary, emoji="📝")
    async def b4(self, interaction, button): cfg = load_config(); await interaction.response.send_modal(ModalDescricao(cfg.get("ticket_descricao", "")))
    @discord.ui.button(label="Modo Abertura", style=discord.ButtonStyle.secondary, emoji="🎚️")
    async def b5(self, interaction, button):
        cfg = load_config(); novo = "select" if cfg.get("modo_abertura") == "botao" else "botao"
        cfg["modo_abertura"] = novo; save_config(cfg)
        await interaction.response.send_message(f"✅ Modo agora: **{novo}**", ephemeral=True)
    @discord.ui.button(label="Categoria", style=discord.ButtonStyle.secondary, emoji="📁", row=1)
    async def b6(self, interaction, button):
        v = discord.ui.View(); v.add_item(SelectCategoria())
        await interaction.response.send_message("Selecione a categoria abaixo:", view=v, ephemeral=True)
    @discord.ui.button(label="Cargo Admin", style=discord.ButtonStyle.secondary, emoji="👮", row=1)
    async def b7(self, interaction, button):
        v = discord.ui.View(); v.add_item(SelectCargoAdmin())
        await interaction.response.send_message("Selecione o cargo abaixo:", view=v, ephemeral=True)
    @discord.ui.button(label="Adicionar Opção", style=discord.ButtonStyle.success, emoji="➕", row=2)
    async def b8(self, interaction, button): await interaction.response.send_modal(ModalAddOpcao())
    @discord.ui.button(label="Limpar Opções", style=discord.ButtonStyle.danger, emoji="🧹", row=2)
    async def b9(self, interaction, button):
        cfg = load_config(); cfg["menu_options"] = []; save_config(cfg)
        await interaction.response.send_message("✅ Todas as opções do menu select foram removidas.", ephemeral=True)
    @discord.ui.button(label="Personalizar Mensagens", style=discord.ButtonStyle.primary, emoji="💬", row=3)
    async def b10(self, interaction, button):
        v = discord.ui.View()
        v.add_item(discord.ui.Button(label="Adicionar", style=discord.ButtonStyle.success, emoji="➕", custom_id="add_msg"))
        v.add_item(discord.ui.Button(label="Remover", style=discord.ButtonStyle.danger, emoji="❌", custom_id="remove_msg"))
        await interaction.response.send_message("Escolha uma opção:", view=v, ephemeral=True)
    @discord.ui.button(label="Status do Bot", style=discord.ButtonStyle.primary, emoji="📍", row=3)
    async def b11(self, interaction, button):
        v = discord.ui.View()
        v.add_item(discord.ui.Button(label="Online", style=discord.ButtonStyle.success, emoji="🟢", custom_id="status_online"))
        v.add_item(discord.ui.Button(label="Idle", style=discord.ButtonStyle.secondary, emoji="🟡", custom_id="status_idle"))
        v.add_item(discord.ui.Button(label="Do Not Disturb", style=discord.ButtonStyle.danger, emoji="🔴", custom_id="status_dnd"))
        v.add_item(discord.ui.Button(label="Invisible", style=discord.ButtonStyle.secondary, emoji="⚫", custom_id="status_invisible"))
        await interaction.response.send_message("Escolha o status:", view=v, ephemeral=True)

class ModalAddMensagem(discord.ui.Modal, title="Adicionar Mensagem ao Perfil"):
    mensagem = discord.ui.TextInput(label="Mensagem", style=discord.TextStyle.short, max_length=128, required=True)
    async def on_submit(self, interaction):
        cfg = load_config()
        msgs = cfg.get("status_messages", [])
        if len(msgs) >= 10:
            await interaction.response.send_message("❌ Máximo de 10 mensagens.", ephemeral=True)
            return
        msgs.append(str(self.mensagem.value))
        cfg["status_messages"] = msgs
        save_config(cfg)
        await interaction.response.send_message(f"✅ Mensagem adicionada: **{self.mensagem.value}**", ephemeral=True)

class SelectRemoverMensagem(discord.ui.Select):
    def __init__(self, msgs):
        options = [discord.SelectOption(label=msg[:100], value=str(i)) for i, msg in enumerate(msgs)]
        super().__init__(placeholder="Selecione a mensagem para remover...", options=options)
    async def callback(self, interaction: discord.Interaction):
        cfg = load_config()
        msgs = cfg.get("status_messages", [])
        idx = int(self.values[0])
        if 0 <= idx < len(msgs):
            removed = msgs.pop(idx)
            cfg["status_messages"] = msgs
            save_config(cfg)
            await interaction.response.send_message(f"✅ Mensagem removida: **{removed}**", ephemeral=True)

@bot.event
async def on_interaction(interaction: discord.Interaction):
    if interaction.type == discord.InteractionType.component:
        custom_id = interaction.data.get("custom_id", "")
        cfg = load_config()
        
        if custom_id == "add_msg":
            await interaction.response.send_modal(ModalAddMensagem())
        elif custom_id == "remove_msg":
            msgs = cfg.get("status_messages", [])
            if not msgs:
                await interaction.response.send_message("❌ Nenhuma mensagem para remover.", ephemeral=True)
                return
            v = discord.ui.View()
            v.add_item(SelectRemoverMensagem(msgs))
            await interaction.response.send_message("Selecione a mensagem:", view=v, ephemeral=True)
        elif custom_id == "status_online":
            await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="👀 Assistindo..."), status=discord.Status.online)
            await interaction.response.send_message("✅ Status alterado para **Online** 🟢", ephemeral=True)
        elif custom_id == "status_idle":
            await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="👀 Assistindo..."), status=discord.Status.idle)
            await interaction.response.send_message("✅ Status alterado para **Idle** 🟡", ephemeral=True)
        elif custom_id == "status_dnd":
            await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="👀 Assistindo..."), status=discord.Status.dnd)
            await interaction.response.send_message("✅ Status alterado para **Do Not Disturb** 🔴", ephemeral=True)
        elif custom_id == "status_invisible":
            await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="👀 Assistindo..."), status=discord.Status.invisible)
            await interaction.response.send_message("✅ Status alterado para **Invisible** ⚫", ephemeral=True)

@bot.tree.command(name="menu", description="Painel de configuração")
async def menu(interaction: discord.Interaction):
    cfg = load_config()
    if not is_owner(interaction.user, cfg):
        await interaction.response.send_message(f"{emj(cfg,'erro')} Apenas o dono pode configurar.", ephemeral=True); return
    embed = discord.Embed(title=f"{emj(cfg,'config')} Painel de Configuração", description=f"**Modo abertura:** `{cfg.get('modo_abertura')}`\n**Categoria:** <#{cfg.get('categoria_tickets_id')}> \n**Cargo Admin:** <@&{cfg.get('admin_role_id')}>\n**Modelo:** `{cfg.get('groq_model', 'llama-3.3-70b-versatile')}`\n**Opções do select:** `{len(cfg.get('menu_options',[]))}`", color=0x5865F2)
    await interaction.response.send_message(embed=embed, view=MenuPrincipal(), ephemeral=True)

@bot.event
async def on_ready():
    global _ready_once
    if _ready_once: return
    _ready_once = True
    bot.add_view(TicketView()); bot.add_view(AbrirBotaoView())
    cfg = load_config()
    if cfg.get("menu_options"): bot.add_view(AbrirSelectView(cfg["menu_options"]))
    await bot.tree.sync()
    print(f"✅ Logado como {bot.user}")
    # Notifica o keep_alive que o bot está online
    notify_keep_alive("bot_online")
    
    # Define um status inicial roxo imediatamente
    try:
        activity = discord.Activity(type=discord.ActivityType.watching, name="👀 Assistindo...")
        await bot.change_presence(activity=activity, status=discord.Status.dnd)
        print("📊 Status roxo definido!")
    except Exception as e:
        print(f"Erro ao definir status inicial: {e}")
    
    # Inicia a tarefa de atualização de status
    bot.loop.create_task(update_bot_status())

async def update_bot_status():
    """Atualiza o status do bot em loop com informações dinâmicas"""
    await bot.wait_until_ready()
    status_index = 0
    while not bot.is_closed():
        try:
            cfg = load_config()
            modelo = cfg.get("groq_model", "llama-3.3-70b-versatile").split("-")[0].upper()
            
            # Lê o arquivo de dados do keep_alive para pegar a contagem de tickets
            try:
                with open("/home/ubuntu/ticket_bot_v3/bot_data.json", "r") as f:
                    bot_data = json.load(f)
                    tickets = bot_data.get("ticketsCreated", 0)
            except:
                tickets = 0
            
            # Alterna entre dois status em loop
            if status_index % 2 == 0:
                status_text = f"👀 {tickets} tickets | 🤖 {modelo}"
            else:
                status_text = f"china ama diabla ❤️"
            
            activity = discord.Activity(
                type=discord.ActivityType.watching,
                name=status_text
            )
            await bot.change_presence(activity=activity, status=discord.Status.dnd)
            print(f"📊 Status atualizado: {status_text}")
            
            status_index += 1
        except Exception as e:
            print(f"Erro ao atualizar status: {e}")
        
        await asyncio.sleep(15)  # Alterna a cada 15 segundos

if __name__ == "__main__":
    # Inicia o servidor keep-alive na porta 8000
    start_keep_alive_server(port=8000)
    
    cfg = load_config()
    bot.run(cfg["token"])
