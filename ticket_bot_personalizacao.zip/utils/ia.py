import aiohttp, json

class IAClient:
    def __init__(self, api_key: str, model: str, system_prompt: str):
        self.api_key = api_key
        self.model = model
        self.system_prompt = system_prompt
        self.url = "https://api.groq.com/openai/v1/chat/completions"

    async def responder(self, historico):
        """Retorna (texto, sem_credito)."""
        if not self.api_key:
            return (None, True)
        msgs = [{"role": "system", "content": self.system_prompt}] + historico
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {"model": self.model, "messages": msgs, "temperature": 0.7, "max_tokens": 800}
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(self.url, headers=headers, json=payload, timeout=60) as r:
                    if r.status in (401, 402, 429):
                        txt = await r.text()
                        low = txt.lower()
                        if "quota" in low or "credit" in low or "insufficient" in low or r.status == 402:
                            return (None, True)
                        if r.status == 401:
                            return (None, True)
                    data = await r.json()
                    if "error" in data:
                        msg = str(data["error"]).lower()
                        if "quota" in msg or "credit" in msg or "insufficient" in msg:
                            return (None, True)
                        return (None, False)
                    texto = data["choices"][0]["message"]["content"]
                    return (texto, False)
        except Exception as e:
            print(f"[IA] Erro: {e}")
            return (None, False)
