import json, os, threading

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")
_lock = threading.Lock()

DEFAULT = {
    "token": "",
    "owner_id": "",
    "groq_api_key": "",
    "groq_model": "llama-3.3-70b-versatile",
    "admins": [],
    "admin_role_id": None,
    "categoria_tickets_id": None,
    "ticket_descricao": "Bem-vindo(a)! Descreva sua dúvida.",
    "modo_abertura": "botao",
    "menu_options": [],
    "prompt_ia": "Você é um assistente de suporte amigável.",
    "creditos_acabaram_avisado": False,
    "emojis": {
        "ticket": "🎫", "ia": "🤖", "fechar": "🔒", "claim": "👋",
        "ok": "✅", "erro": "❌", "config": "⚙️", "estrela": "⭐"
    },
}

def load_config():
    with _lock:
        if not os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(DEFAULT, f, indent=2, ensure_ascii=False)
            return dict(DEFAULT)
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        # merge defaults
        for k, v in DEFAULT.items():
            if k not in data:
                data[k] = v
        return data

def save_config(cfg):
    with _lock:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)

def is_owner(user, cfg):
    return str(user.id) == str(cfg.get("owner_id", ""))

def is_admin(user, cfg):
    if is_owner(user, cfg):
        return True
    if str(user.id) in [str(x) for x in cfg.get("admins", [])]:
        return True
    role_id = cfg.get("admin_role_id")
    if role_id:
        try:
            if any(str(r.id) == str(role_id) for r in getattr(user, "roles", [])):
                return True
        except Exception:
            pass
    # fallback: server admin permission
    try:
        if user.guild_permissions.administrator:
            return True
    except Exception:
        pass
    return False
