"""
Servidor web para manter o bot online 24/7 e sincronizar dados em tempo real
"""

from flask import Flask, jsonify, request
import threading
import json
import os
from datetime import datetime

app = Flask(__name__)

# Status global do bot - sincronizado com o bot Discord
bot_data = {
    "online": True,
    "uptime": 0,
    "version": "3.0",
    "tickets_created": 0,
    "messages_processed": 0,
    "last_check": datetime.now().isoformat(),
    "discord_connection": "CONNECTED",
    "api_status": "OPERATIONAL",
    "keep_alive_active": True
}

# Arquivo para persistência de dados
DATA_FILE = "/home/ubuntu/ticket_bot_v3/bot_data.json"

def load_bot_data():
    """Carrega os dados do bot do arquivo"""
    global bot_data
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                saved_data = json.load(f)
                bot_data.update(saved_data)
    except Exception as e:
        print(f"Erro ao carregar dados: {e}")

def save_bot_data():
    """Salva os dados do bot em arquivo"""
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(bot_data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"Erro ao salvar dados: {e}")

# Carregar dados na inicialização
load_bot_data()

@app.route('/', methods=['GET'])
def home():
    """Endpoint raiz - verifica se o servidor está respondendo"""
    return jsonify({"status": "ok", "message": "Bot keep-alive server is running"}), 200

@app.route('/api/status', methods=['GET'])
def status():
    """Endpoint de status - retorna informações do bot em tempo real"""
    bot_data["last_check"] = datetime.now().isoformat()
    return jsonify({
        "online": True,  # Sempre true porque se está respondendo, está online
        "uptime": bot_data.get("uptime", 0),
        "version": bot_data.get("version", "3.0"),
        "ticketsCreated": bot_data.get("tickets_created", 0),
        "messagesProcessed": bot_data.get("messages_processed", 0),
        "lastCheck": bot_data.get("last_check"),
        "discordConnection": "CONNECTED",
        "apiStatus": "OPERATIONAL",
        "keepAliveActive": True
    }), 200

@app.route('/api/health', methods=['GET'])
def health():
    """Endpoint de saúde - para UptimeRobot"""
    return jsonify({
        "healthy": True,
        "status": "running",
        "bot_online": True,
        "timestamp": datetime.now().isoformat()
    }), 200

@app.route('/api/ping', methods=['GET'])
def ping():
    """Endpoint de ping - simples verificação de disponibilidade"""
    return jsonify({"pong": True, "online": True}), 200

@app.route('/api/bot-event', methods=['POST'])
def bot_event():
    """Endpoint para receber eventos do bot e atualizar dados"""
    try:
        data = request.get_json()
        
        if data.get("event") == "ticket_created":
            bot_data["tickets_created"] = bot_data.get("tickets_created", 0) + 1
            save_bot_data()
            
        elif data.get("event") == "message_processed":
            bot_data["messages_processed"] = bot_data.get("messages_processed", 0) + 1
            save_bot_data()
            
        elif data.get("event") == "uptime_update":
            bot_data["uptime"] = data.get("uptime", 0)
            save_bot_data()
            
        elif data.get("event") == "bot_online":
            bot_data["online"] = True
            bot_data["discord_connection"] = "CONNECTED"
            save_bot_data()
            
        elif data.get("event") == "bot_offline":
            bot_data["online"] = False
            bot_data["discord_connection"] = "DISCONNECTED"
            save_bot_data()
        
        bot_data["last_check"] = datetime.now().isoformat()
        
        return jsonify({"success": True, "message": "Event received"}), 200
    except Exception as e:
        print(f"Erro ao processar evento: {e}")
        return jsonify({"success": False, "error": str(e)}), 400

@app.route('/api/data', methods=['GET'])
def get_data():
    """Retorna todos os dados do bot"""
    bot_data["last_check"] = datetime.now().isoformat()
    return jsonify(bot_data), 200

@app.route('/api/data', methods=['POST'])
def update_data():
    """Atualiza os dados do bot"""
    try:
        data = request.get_json()
        bot_data.update(data)
        bot_data["last_check"] = datetime.now().isoformat()
        save_bot_data()
        return jsonify({"success": True, "data": bot_data}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400

def run_server(port=8000):
    """Inicia o servidor Flask"""
    app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False, threaded=True)

def start_keep_alive_server(port=8000):
    """Inicia o servidor em uma thread separada"""
    thread = threading.Thread(target=run_server, args=(port,), daemon=True)
    thread.start()
    print(f"✅ Keep-alive server iniciado na porta {port}")

if __name__ == "__main__":
    run_server()
