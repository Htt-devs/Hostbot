"""
Painel Admin Standalone para gerenciar Keys, Bots e Subscrições
Roda em http://localhost:5000
"""

from flask import Flask, render_template_string, request, jsonify
from flask_cors import CORS
import json
import os
from datetime import datetime, timedelta
import secrets
import string

app = Flask(__name__)
CORS(app)

# Arquivo de armazenamento de dados
DATA_FILE = "/home/ubuntu/ticket_bot_v3/admin_data.json"
ADMIN_PASSWORD = "admin@keybot.com"  # Senha padrão

def load_data():
    """Carrega os dados do arquivo"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "keys": [],
        "users": [],
        "bots": [],
        "chat": []
    }

def save_data(data):
    """Salva os dados no arquivo"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def generate_key(hours=24):
    """Gera uma key no formato KEY-XXXX-XXXX"""
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    key = "KEY-"
    for i in range(4):
        for j in range(4):
            key += secrets.choice(chars)
        if i < 3:
            key += "-"
    
    expires_at = (datetime.now() + timedelta(hours=hours)).isoformat()
    
    return {
        "code": key,
        "created_at": datetime.now().isoformat(),
        "expires_at": expires_at,
        "is_used": False,
        "used_by": None,
        "used_at": None
    }

# HTML do Painel Admin
ADMIN_HTML = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔑 Painel Admin - Ticket Bot SaaS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .header h1 {
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #666;
        }
        
        .main-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .card h2 {
            color: #667eea;
            margin-bottom: 20px;
            font-size: 1.5em;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: 500;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        button {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
            width: 100%;
        }
        
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .keys-list {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            max-height: 400px;
            overflow-y: auto;
        }
        
        .key-item {
            background: white;
            padding: 12px;
            margin-bottom: 10px;
            border-radius: 5px;
            border-left: 4px solid #667eea;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .key-code {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            color: #667eea;
        }
        
        .key-status {
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 3px;
            background: #e0e0e0;
            color: #666;
        }
        
        .key-status.active {
            background: #4caf50;
            color: white;
        }
        
        .key-status.used {
            background: #ff9800;
            color: white;
        }
        
        .key-status.expired {
            background: #f44336;
            color: white;
        }
        
        .success {
            background: #4caf50;
            color: white;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            display: none;
        }
        
        .success.show {
            display: block;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .stat-box {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
        }
        
        .stat-number {
            font-size: 2em;
            font-weight: bold;
        }
        
        .stat-label {
            font-size: 0.9em;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔑 Painel Admin - Ticket Bot SaaS</h1>
            <p>Gerenciar Keys, Usuários e Bots</p>
        </div>
        
        <div class="main-grid">
            <!-- Gerar Nova Key -->
            <div class="card">
                <h2>🔐 Gerar Nova Key</h2>
                <div id="success" class="success"></div>
                
                <div class="form-group">
                    <label for="duration">Duração:</label>
                    <select id="duration">
                        <option value="24">24 horas</option>
                        <option value="72">3 dias</option>
                        <option value="168">7 dias</option>
                        <option value="720">30 dias</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="email">Email do Usuário:</label>
                    <input type="email" id="email" placeholder="usuario@example.com">
                </div>
                
                <button onclick="generateKey()">Gerar Key</button>
            </div>
            
            <!-- Estatísticas -->
            <div class="card">
                <h2>📊 Estatísticas</h2>
                <div class="stats">
                    <div class="stat-box">
                        <div class="stat-number" id="totalKeys">0</div>
                        <div class="stat-label">Keys Totais</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-number" id="activeKeys">0</div>
                        <div class="stat-label">Ativas</div>
                    </div>
                    <div class="stat-box">
                        <div class="stat-number" id="usedKeys">0</div>
                        <div class="stat-label">Usadas</div>
                    </div>
                </div>
            </div>
            
            <!-- Configurar Bot -->
            <div class="card">
                <h2>🤖 Configurar Bot</h2>
                
                <div class="form-group">
                    <label for="botToken">Token do Bot:</label>
                    <input type="password" id="botToken" placeholder="Seu token Discord">
                </div>
                
                <div class="form-group">
                    <label for="groqKey">API Key Groq:</label>
                    <input type="password" id="groqKey" placeholder="Sua API key Groq">
                </div>
                
                <button onclick="saveBotConfig()">Salvar Configuração</button>
            </div>
        </div>
        
        <!-- Lista de Keys -->
        <div class="card">
            <h2>📋 Keys Geradas</h2>
            <div class="keys-list" id="keysList">
                <p style="color: #999; text-align: center;">Nenhuma key gerada ainda</p>
            </div>
        </div>
    </div>
    
    <script>
        // Carregar dados ao iniciar
        loadData();
        
        function loadData() {
            fetch('/api/data')
                .then(r => r.json())
                .then(data => {
                    updateStats(data);
                    updateKeysList(data);
                })
                .catch(e => console.error('Erro ao carregar dados:', e));
        }
        
        function updateStats(data) {
            const totalKeys = data.keys.length;
            const activeKeys = data.keys.filter(k => !k.is_used && new Date(k.expires_at) > new Date()).length;
            const usedKeys = data.keys.filter(k => k.is_used).length;
            
            document.getElementById('totalKeys').textContent = totalKeys;
            document.getElementById('activeKeys').textContent = activeKeys;
            document.getElementById('usedKeys').textContent = usedKeys;
        }
        
        function updateKeysList(data) {
            const list = document.getElementById('keysList');
            if (data.keys.length === 0) {
                list.innerHTML = '<p style="color: #999; text-align: center;">Nenhuma key gerada ainda</p>';
                return;
            }
            
            list.innerHTML = data.keys.map(key => {
                const expires = new Date(key.expires_at);
                const now = new Date();
                let status = 'active';
                let statusText = '✅ Ativa';
                
                if (key.is_used) {
                    status = 'used';
                    statusText = '✓ Usada';
                } else if (expires < now) {
                    status = 'expired';
                    statusText = '❌ Expirada';
                }
                
                return `
                    <div class="key-item">
                        <div>
                            <div class="key-code">${key.code}</div>
                            <small style="color: #999;">Expira: ${expires.toLocaleString('pt-BR')}</small>
                        </div>
                        <div class="key-status ${status}">${statusText}</div>
                    </div>
                `;
            }).join('');
        }
        
        function generateKey() {
            const duration = document.getElementById('duration').value;
            const email = document.getElementById('email').value;
            
            if (!email) {
                alert('Por favor, insira um email');
                return;
            }
            
            fetch('/api/generate-key', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ duration: parseInt(duration), email })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showSuccess(`✅ Key gerada: ${data.key}`);
                    document.getElementById('email').value = '';
                    loadData();
                } else {
                    alert('Erro ao gerar key');
                }
            });
        }
        
        function saveBotConfig() {
            const botToken = document.getElementById('botToken').value;
            const groqKey = document.getElementById('groqKey').value;
            
            if (!botToken || !groqKey) {
                alert('Preencha todos os campos');
                return;
            }
            
            fetch('/api/save-bot-config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ botToken, groqKey })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showSuccess('✅ Configuração salva com sucesso!');
                    document.getElementById('botToken').value = '';
                    document.getElementById('groqKey').value = '';
                } else {
                    alert('Erro ao salvar configuração');
                }
            });
        }
        
        function showSuccess(message) {
            const el = document.getElementById('success');
            el.textContent = message;
            el.classList.add('show');
            setTimeout(() => el.classList.remove('show'), 3000);
        }
        
        // Atualizar dados a cada 5 segundos
        setInterval(loadData, 5000);
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    """Página principal do painel admin"""
    return render_template_string(ADMIN_HTML)

@app.route('/api/data', methods=['GET'])
def get_data():
    """Retorna todos os dados"""
    return jsonify(load_data())

@app.route('/api/generate-key', methods=['POST'])
def api_generate_key():
    """Gera uma nova key"""
    try:
        data = request.get_json()
        duration = data.get('duration', 24)
        email = data.get('email', 'unknown')
        
        new_key = generate_key(duration)
        
        all_data = load_data()
        all_data['keys'].append(new_key)
        all_data['users'].append({
            'email': email,
            'key_code': new_key['code'],
            'created_at': datetime.now().isoformat()
        })
        save_data(all_data)
        
        return jsonify({
            'success': True,
            'key': new_key['code'],
            'expires_at': new_key['expires_at']
        })
    except Exception as e:
        print(f"Erro ao gerar key: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/save-bot-config', methods=['POST'])
def api_save_bot_config():
    """Salva configuração do bot"""
    try:
        data = request.get_json()
        
        all_data = load_data()
        all_data['bots'].append({
            'token': data.get('botToken'),
            'groq_key': data.get('groqKey'),
            'created_at': datetime.now().isoformat()
        })
        save_data(all_data)
        
        return jsonify({'success': True})
    except Exception as e:
        print(f"Erro ao salvar config: {e}")
        return jsonify({'success': False, 'error': str(e)})

def run_admin_server(port=5000):
    """Inicia o servidor admin"""
    print(f"✅ Painel Admin iniciado em http://localhost:{port}")
    app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False)

if __name__ == "__main__":
    run_admin_server()
